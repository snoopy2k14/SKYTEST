package com.bskyb.internettv.thirdparty;

import org.junit.Test;



import junit.framework.Assert;

public class MovieServiceImplTest {
	
	MovieServiceImpl movieServiceImpl = new MovieServiceImpl();
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetParentalControlLevel_15() throws TitleNotFoundException, TechnicalFailureException{
		Assert.assertEquals("15",movieServiceImpl.getParentalControlLevel("103"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetParentalControlLevel_15_2() throws TitleNotFoundException, TechnicalFailureException{
		Assert.assertEquals("15",movieServiceImpl.getParentalControlLevel("203"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetParentalControlLevel_U() throws TitleNotFoundException, TechnicalFailureException{
		Assert.assertEquals("U",movieServiceImpl.getParentalControlLevel("100"));
	}
	
	
	@Test(expected = TitleNotFoundException.class)
	public void testTitleNotFoundException() throws TitleNotFoundException, TechnicalFailureException {
		String parentalControl = movieServiceImpl.getParentalControlLevel("300");
		
	}
	
	@Test(expected = TechnicalFailureException.class)
	public void testTechnicalFailureExceptionforNull() throws TitleNotFoundException, TechnicalFailureException {
		String parentalControl = movieServiceImpl.getParentalControlLevel(null);
	}
	
	
	
	@Test(expected = TechnicalFailureException.class)
	public void testTechnicalFailureExceptionForEmpty() throws TitleNotFoundException, TechnicalFailureException {
		String parentalControl = movieServiceImpl.getParentalControlLevel("");
	}
	

}
