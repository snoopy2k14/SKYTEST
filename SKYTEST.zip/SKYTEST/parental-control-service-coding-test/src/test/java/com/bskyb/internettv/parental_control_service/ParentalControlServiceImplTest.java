package com.bskyb.internettv.parental_control_service;

import org.junit.Test;

import junit.framework.Assert;

public class ParentalControlServiceImplTest {
	
	
	ParentalControlServiceImpl parentalControlServiceImpl = new ParentalControlServiceImpl();
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_U_MPC_U() throws Exception{
		Assert.assertTrue(parentalControlServiceImpl.canWatchMovie("U", "100"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_U_MPC_PG() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("U", "101"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_U_MPC_12() throws Exception{
		Assert.assertTrue(parentalControlServiceImpl.canWatchMovie("U", "102"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_U_MPC_15() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("U", "103"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_U_MPC_18() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("U", "104"));
	}

//-------------------
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_PG_MPC_U() throws Exception{
		Assert.assertFalse(parentalControlServiceImpl.canWatchMovie("PG", "100"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_PG_MPC_PG() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("PG", "101"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_PG_MPC_12() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("PG", "102"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_PG_MPC_15() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("PG", "103"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_PG_MPC_18() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("PG", "104"));
	}
//------------------------------
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_12_MPC_U() throws Exception{
		Assert.assertEquals(false, parentalControlServiceImpl.canWatchMovie("12", "100"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_12_MPC_PG() throws Exception{
		Assert.assertEquals(false, parentalControlServiceImpl.canWatchMovie("12", "101"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_12_MPC_12() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("12", "102"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_12_MPC_15() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("12", "103"));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCanWatchMovie_PCL_12_MPC_18() throws Exception{
		Assert.assertEquals(true, parentalControlServiceImpl.canWatchMovie("12", "104"));
	}
	
	
}
