package com.bskyb.internettv.thirdparty;

public class TechnicalFailureException extends Exception {
	
	private static final long serialVersionUID = 1L;


	public TechnicalFailureException(String message) {
        super(message);
    }
}





