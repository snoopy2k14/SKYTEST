package com.bskyb.internettv.parental_control_service;

import com.bskyb.internettv.thirdparty.MovieServiceImpl;

public class ParentalControlServiceImpl implements ParentalControlService{
	
	
	
	@Override
	public boolean canWatchMovie(String customerParentalControlLevel, String movieId) throws Exception{
		
		MovieServiceImpl movieServiceImpl = new MovieServiceImpl();	
		String movieParentalControl = movieServiceImpl.getParentalControlLevel(movieId);
		boolean returnType = false;
		
		if(customerParentalControlLevel.equalsIgnoreCase("U")) {
			return true;
		}else if(customerParentalControlLevel.equalsIgnoreCase("PG")) {
			if(movieParentalControl.equalsIgnoreCase("U")) {
				returnType = false;
			}else {
				returnType = true;
			}
		}else if(customerParentalControlLevel.equalsIgnoreCase("12")) {
			if(movieParentalControl.equalsIgnoreCase("U") || movieParentalControl.equalsIgnoreCase("PG")) {
				returnType = false;
			}else {
				returnType = true;
			}
		}else if(customerParentalControlLevel.equalsIgnoreCase("15")) {
			if(movieParentalControl.equalsIgnoreCase("U") || movieParentalControl.equalsIgnoreCase("PG") || movieParentalControl.equalsIgnoreCase("12")) {
				returnType = false;
			}else {
				returnType = true;
			}
		}else if(customerParentalControlLevel.equalsIgnoreCase("18")) {
			if(movieParentalControl.equalsIgnoreCase("U") || movieParentalControl.equalsIgnoreCase("PG") || movieParentalControl.equalsIgnoreCase("12") || movieParentalControl.equalsIgnoreCase("15")) {
				returnType = false;
			}else {
				returnType = true;
			}

		}
		return returnType;
	}
	
}
