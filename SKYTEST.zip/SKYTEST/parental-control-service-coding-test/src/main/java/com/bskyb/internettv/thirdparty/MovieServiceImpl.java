package com.bskyb.internettv.thirdparty;

import java.util.HashMap;

public class MovieServiceImpl implements MovieService{

	
	HashMap<String, String> hmap = new HashMap<String, String>();
	
	public MovieServiceImpl() {
		
		  /*Adding elements to HashMap to storw movie id and its corresponding parental guidance rating*/ 
		  // Here the key is the movie id and the value is the movie parental control
	      hmap.put("100", "U");
	      hmap.put("101", "PG");
	      hmap.put("102", "12");
	      hmap.put("103", "15");
	      hmap.put("104", "18");
	      
	      hmap.put("200", "U");
	      hmap.put("201", "PG");
	      hmap.put("202", "12");
	      hmap.put("203", "15");
	      hmap.put("204", "18");
		
	}
	
	
	@Override
	public String getParentalControlLevel(String titleId) throws TitleNotFoundException, TechnicalFailureException {
		
		if((titleId == null) || (titleId.isEmpty())) {
			System.out.println("Technical failure");
			throw new TechnicalFailureException("Technical Failure Exception");
		}else {
			
			String parentalControlLevel= hmap.get(titleId);  
			if(parentalControlLevel!= null && !parentalControlLevel.isEmpty()) {
				return parentalControlLevel;
			}else {
				System.out.println("The Movie title could not be found");
				throw new TitleNotFoundException("Movie Title not found");
				
			}
			
		}
			
	}
	
	
	public void displayMovieRating() {
		
		for (HashMap.Entry<String, String> entry : hmap.entrySet()) {
		    String key = entry.getKey();
		    String value = entry.getValue();
		    
		    System.out.println("Movied Id: " + key + "   Movie Control Level: " + value);
		    // ...
		}
		
	}

}
