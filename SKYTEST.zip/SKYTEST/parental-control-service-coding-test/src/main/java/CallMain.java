import com.bskyb.internettv.parental_control_service.ParentalControlService;
import com.bskyb.internettv.parental_control_service.ParentalControlServiceImpl;
import com.bskyb.internettv.thirdparty.MovieServiceImpl;
import com.bskyb.internettv.thirdparty.TechnicalFailureException;
import com.bskyb.internettv.thirdparty.TitleNotFoundException;

public class CallMain {
	
	
	
	public static void main(String[] args) throws TitleNotFoundException, TechnicalFailureException {
		
		MovieServiceImpl msi = new MovieServiceImpl();
		//Displaying all available movie titles and their control levels
		msi.displayMovieRating();
		//String pc1 = msi.getParentalControlLevel(null); //To check technical failure exception uncomment this line and run
		//String pc2 = msi.getParentalControlLevel(""); //To check technical failure exception uncomment this line and run
		//String pc3 = msi.getParentalControlLevel("300"); //To check Title not found exception uncomment this line and runn
		
		
		
		//Just a sample test to check if a customer can watch a movie given a movieId and the customer control level
		ParentalControlServiceImpl pcs = new ParentalControlServiceImpl();
		try {
			Boolean canWatch = pcs.canWatchMovie("18", "104");
			if(canWatch == true) {
				System.out.println("Customer can watch the movie");
			}else {
				System.out.println("Sorry, can't watch the movie");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	

}
